Thanks for downloading my projects!

To run, make sure the archive is unzipped and python is installed.

Then, open a terminal and move to the directory where the files are.

Run chmod +x macAndLinux.sh (to enable executing the file).

Then run ./macAndLinux.sh.
Thanks for downloading my projects.

Make sure the archive is unzipped and python is installed.

Then, open File Explorer, go to the directory where you unzipped the file, and double click windows.bat.
Thanks for downloading the source!

To run a file, make sure python is installed on your computer and the archive is unzipped.

Then, you can run it via command line with python file.py (where file is the file's name.) or python3 file.py.

You can also open it in IDLE by opening IDLE on your computer, and clicking File, Open, selecting the file, and then clicking Run, Run Module.